pytest tests --cov-report html --cov=autokeras --cov-config .coveragerc
