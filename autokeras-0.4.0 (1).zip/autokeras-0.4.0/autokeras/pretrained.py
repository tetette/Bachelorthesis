try:
    from autokeras_pretrained import *
except ModuleNotFoundError:
    print('Please install autokeras-pretrained.')
