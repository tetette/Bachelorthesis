This pull request resolves #ISSUE_NUMBER.

The pull request is in progress.
OR
The pull request is ready to be merged.

The details of the pull request:
