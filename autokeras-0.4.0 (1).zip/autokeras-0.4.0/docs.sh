#!/usr/bin/env bash
cd mkdocs
sh build.sh